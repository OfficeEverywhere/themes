# Native Bootswatch Themes

Native Bootswatch Themes in Odoo:<br>
Darkly, Paper, Sandstone and Superhero<br>

Repository: <a href="https://github.com/OfficeEverywhere/themes/tree/8.0/theme_bootswatch_native">Native Bootswatch Themes</a><br>
Source: https://bootswatch.com/

<IMG SRC="https://www.office-everywhere.com/website/image/ir.attachment/1084_f488c02/datas" ALT="Free Bootswatch">

# Copyright and License

Bootswatch version: 3.3.5 <br>
Copyright 2012-2015 Thomas Park <br>
Licensed under MIT <br>
Based on Bootstrap <br>
Homepage: <a href=http://bootstrap.com target="_blank">bootstrap.com</a>

<IMG SRC="https://www.office-everywhere.com/website/image/ir.attachment/351_ffc5997/datas" ALT="Office Everywhere - Themes">

# Office Everywhere

We build websites that will build your business.<br>

Design, Development, Implementation, Hosting, Marketing & Sales.<br>
From Back Office to Front Office and all your Apps in a Single Database.<br>

We don’t just build websites, we build your business.<br>

w: <a href=https://www.office-everywhere.com>Office-Everywhere.com</a><br>
e: <a href=mailto:support@office-everywhere.com>Email Support</a><br>
