{
    'name': "Bootswatch Sandstone",

    'summary': """
    Bootswatch Sandstone""",

    'description': """
    Bootswatch Sandstone Theme https://bootswatch.com/sandstone/""",

    'author': "Office Everywhere",
    'website': "https://www.office-everywhere.com",

    'category': 'Theme',
    'version': '1.0',

    'images':[
        'images/sandstone-thumbnail.png'
    ],

    'depends': [
        'website'
    ],
    'data': [
        'views/bootswatch-sandstone.xml'
    ],

    'demo': [
    ],

    'tests': [
    ],
}
