{
    'name': "Theme Paper",

    'summary': """
    Theme Paper""",

    'description': """
    Bootswatch Paper Theme https://bootswatch.com/paper/""",

    'author': "Office Everywhere",
    'website': "https://www.office-everywhere.com",

    'category': 'Theme',
    'version': '1.0',

    'depends': [
        'website'
    ],
    'data': [
#        'views/layout.xml',
#        'views/assets.xml'
        'views/bootswatch-paper.xml'
    ],

    'demo': [
    ],

    'tests': [
    ],
}
