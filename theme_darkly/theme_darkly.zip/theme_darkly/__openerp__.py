{
    'name': "Theme Bootswatch Darkly",

    'summary': """
    Theme Bootswatch Darkly""",

    'description': """
    Bootswatch Paper Theme https://bootswatch.com/darkly/""",

    'author': "Office Everywhere",
    'website': "https://www.office-everywhere.com",

    'category': 'Theme',
    'version': '1.0',

    'depends': [
        'website'
    ],
    'data': [
        'views/bootswatch-darkly.xml'
    ],

    'demo': [
    ],

    'tests': [
    ],
}
