<IMG SRC="https://www.office-everywhere.com/website/image/ir.attachment/351_ffc5997/datas" ALT="Office Everywhere - Themes">

# FREE THEMES

Odoo verion 8.0 Themes

# Bootswatch Themes

Missing Bootswatch Themes in Odoo:<br>
Darkly, Paper, Sandstone and Superhero<br>

Theme Darkly:<br>
Repositorie: <a href="https://github.com/OfficeEverywhere/themes/tree/8.0/bootswatch/theme_darkly">Theme Darkly</a><br>
Source: https://bootswatch.com/darkly/


Theme Paper:<br>
Repositorie: <a href="https://github.com/OfficeEverywhere/themes/tree/8.0/bootswatch/theme_paper">Theme Paper</a><br>
Source: https://bootswatch.com/paper/

Theme Sandstone:<br>
Repositorie: <a href="https://github.com/OfficeEverywhere/themes/tree/8.0/bootswatch/theme_sandstone">Theme Sandstone</a><br>
Source: https://bootswatch.com/sandstone/

Bootswatch Theme Superhero:<br>
Repositorie: <a href="https://github.com/OfficeEverywhere/themes/tree/8.0/bootswatch/theme_darkly">Theme Superhero</a><br>
Source: https://bootswatch.com/superhero/


# Support - Themes

Office Everywhere<br>
w: <a href=https://www.office-everywhere.com>Office-Everywhere.com</a><br>
e: <a href=mailto:support@office-everywhere.com>Email Support</a><br>

# Copyright and License

Bootswatch version: 3.3.5 <br>
Copyright 2012-2015 Thomas Park <br>
Licensed under MIT <br>
Based on Bootstrap <br>
Homepage: <a href=http://bootstrap.com target="_blank">bootstrap.com</a><br>

<IMG SRC="https://www.office-everywhere.com/website/image/ir.attachment/1084_f488c02/datas" ALT="Github">
