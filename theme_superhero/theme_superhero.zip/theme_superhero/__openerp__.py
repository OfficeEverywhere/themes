{
    'name': "Bootswatch Superhero",

    'summary': """
    Bootswatch Superhero""",

    'description': """
    Bootswatch Paper Theme https://bootswatch.com/superhero/""",

    'author': "Office Everywhere",
    'website': "https://www.office-everywhere.com",

    'category': 'Theme',
    'version': '1.0',

    'images':[
        'images/superhero-thumbnail.png'
    ],

    'depends': [
        'website'
    ],
    'data': [
        'views/bootswatch-superhero.xml'
    ],

    'demo': [
    ],

    'tests': [
    ],
}
