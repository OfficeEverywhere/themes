{
    'name': "Theme Bootswatch Superhero",

    'summary': """
    Theme Bootswatch Superhero""",

    'description': """
    Bootswatch Paper Theme https://bootswatch.com/superhero/""",

    'author': "Office Everywhere",
    'website': "https://www.office-everywhere.com",

    'category': 'Theme',
    'version': '1.0',

    'depends': [
        'website'
    ],
    'data': [
        'views/bootswatch-superhero.xml'
    ],

    'demo': [
    ],

    'tests': [
    ],
}
